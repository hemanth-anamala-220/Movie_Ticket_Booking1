import { useLocation } from "react-router-dom";
import { useState } from "react";

const TENAM = () => {
    const location = useLocation();
    const movie = location.state?.movie; // Get movie details
    const [selectedSeats, setSelectedSeats] = useState([]);
    const totalRows = 20;
    const seatsPerRow = 15;
    const rowLabels = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");
    
    const toggleSeatSelection = (seatNumber) => {
        setSelectedSeats(prev => 
            prev.includes(seatNumber)
                ? prev.filter(seat => seat !== seatNumber)
                : [...prev, seatNumber]
        );
    };

    const handlePayment = () => {
        alert(`Payment successful for seats: ${selectedSeats.join(", ")}`);
        setSelectedSeats([]); // Reset selected seats after payment
    };

    return (
        <>
            <div>
                <h1>Welcome to 10:00 AM Show</h1>
                {movie ? (
                    <>
                        <h2>{movie.title}</h2>
                        <img src={movie.image} alt={movie.title} width="200" />
                        <p><strong>Description:</strong> {movie.description}</p>
                        <p><strong>Rating:</strong> ⭐ {movie.rating} / 5</p>

                        <h3>Select Your Seats</h3>
                        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "5px" }}>
                            {[...Array(totalRows)].map((_, rowIndex) => (
                                <div 
                                    key={rowIndex} 
                                    style={{ 
                                        display: "flex", 
                                        justifyContent: "center", 
                                        gap: rowIndex % 5 === 4 ? "20px" : "10px" // Add larger gaps for aisles
                                    }}
                                >
                                    {[...Array(seatsPerRow)].map((_, colIndex) => {
                                        const seatLabel = `${rowLabels[rowIndex]}${colIndex + 1}`;
                                        return (
                                            <button 
                                                key={seatLabel} 
                                                onClick={() => toggleSeatSelection(seatLabel)}
                                                style={{ 
                                                    padding: "10px", 
                                                    width: "40px", 
                                                    backgroundColor: selectedSeats.includes(seatLabel) ? "green" : "gray", 
                                                    color: "white", 
                                                    border: "none", 
                                                    cursor: "pointer", 
                                                    textAlign: "center", 
                                                    borderRadius: "5px", 
                                                    marginRight: colIndex % 5 === 4 ? "20px" : "5px" // Add gaps for aisles
                                                }}
                                            >
                                                {seatLabel}
                                            </button>
                                        );
                                    })}
                                </div>
                            ))}
                        </div>
                        <p>Selected Seats: {selectedSeats.join(", ") || "None"}</p>
                        <button 
                            onClick={handlePayment} 
                            disabled={selectedSeats.length === 0}
                            style={{ 
                                marginTop: "20px", 
                                padding: "10px 20px", 
                                backgroundColor: "blue", 
                                color: "white", 
                                border: "none", 
                                cursor: selectedSeats.length === 0 ? "not-allowed" : "pointer" 
                            }}
                        >
                            Pay Now
                        </button>
                    </>
                ) : (
                    <p>No movie selected.</p>
                )}
            </div>
        </>
    );
};

export default TENAM;