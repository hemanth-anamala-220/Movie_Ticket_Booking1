import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import "./MovieDetails.css";

// Importing movie images
import Hanuman from "../assets/Hanuman.avif";
import salaar1 from "../assets/salaar1.png";
import skanda1 from "../assets/skanda1.png";
import KGF2 from "../assets/KGF2.png";
import Image from "../assets/movie.png";
import Mad2 from "../assets/Mad2.jpg";
import GameChanger from "../assets/Gamechanger.png";
import SeethammaVakitloSirimalleChettu from "../assets/Seethamma-Vakitlo-Sirimalle-Chettu.jpg";
import HIT2 from "../assets/HIT3.jpeg";
import Rajasaba from "../assets/Rajasaba.jpeg";
import Dilruba from "../assets/Dilruba.jpg";
import SankranthiVasthunam from "../assets/SankranthiVasthunam.avif";
import ENDGAME from "../assets/ENDGAME.jpg";
import InfinityWar from "../assets/InfinityWar.jpg";
import Orange from "../assets/Orange.jpeg";
import JUMANJI from "../assets/JUMANJI.jpeg";

const movies = [
    { id: 1, title: "Jai Hanuman", image: Hanuman, 
        description: "Hanuman is a 2024 Indian superhero film inspired by the Hindu deity Hanuman...", 
        rating: 4.5, trailer: "https://www.youtube.com/embed/BUt-Ncdff50?" 
    },
    { id: 2, title: "Salaar", image: salaar1, 
        description: "An action thriller starring Prabhas with high-voltage action sequences...", 
        rating: 4.6, 
        trailer: "https://www.youtube.com/embed/4GPvYMKtrtI?"
     },
    { id: 3, title: "Skanda", image: skanda1,
         description: "A high-energy action movie packed with emotions and powerful storytelling...", 
         rating: 4.4,
          trailer: "https://www.youtube.com/embed/rFnxNiiw1wI?" },
    { id: 4, title: "KGF 2", image: KGF2, 
        description: "Sequel to KGF, a massive blockbuster with intense action and emotional depth...",
         rating: 4.8, 
         trailer: "https://www.youtube.com/embed/bDTUFufX-1s?" 
        },
    { id: 5,
        title: "Court", 
        image: Image, 
        description: "A thought-provoking film with deep storytelling and artistic cinematography...", 
        rating: 4.2, 
        trailer: "https://www.youtube.com/embed/urrUjvUFhxE?"
     },
    { id: 6, 
        title: "Mad2", 
        image: Mad2, 
        description: "A hilarious comedy-drama packed with entertainment and humor...", 
        rating: 4.1, 
        trailer: "https://www.youtube.com/embed/x9jlQ0_K5Zc?"
     },
    { id: 7, 
        title: "Game Changer", 
        image: GameChanger, 
        description: "A political thriller starring Ram Charan, directed by Shankar...", 
        rating: 4.7, 
        trailer: "https://www.youtube.com/embed/EqDlrimnMCE?" 
    },
    { id: 8, title: "Seethamma Vakitlo Sirimalle Chettu", 
        image: SeethammaVakitloSirimalleChettu, 
        description: "A heartwarming Telugu family drama featuring Mahesh Babu and Venkatesh...", 
        rating: 4.5, 
        trailer: "https://www.youtube.com/embed/_c840-Ahuok?" 
    },
    { id: 9,
        title: "HIT 2", image: HIT2,
         description: "A gripping crime thriller that keeps you on the edge of your seat...", 
         rating: 4.6, 
         trailer: "https://www.youtube.com/embed/XhW3i2f54BQ?"
         },
    { id: 10, 
        title: "Rajasaba", image: Rajasaba,
         description: "A gripping political drama exploring power, governance, and corruption...", 
         rating: 4.3, 
         trailer: "https://www.youtube.com/embed/YFZMBqyXkqQ?"
        
        },
    { id: 11, 
        title: "Dilruba", 
        image: Dilruba, 
        description: "A romantic drama that delves deep into love, heartbreak, and destiny...", 
        rating: 4.2, 
        trailer: "https://www.youtube.com/embed/STAEe52jgJU?"
     },
    { id: 12, 
        title: "Sankranthi Vasthunam", 
        image: SankranthiVasthunam, 
        description: "A festival-themed movie with cultural significance...", 
        rating: 4.2, 
        trailer: "https://www.youtube.com/embed/yCkl2Z3PBs0?" 
    },
    { id: 13, 
        title: "Avengers: Endgame", 
        image: ENDGAME, 
        description: "The epic conclusion to the Marvel Cinematic Universe's Infinity Saga...", 
        rating: 4.9,
         trailer: "https://www.youtube.com/embed/TcMBFSGVi1c?" 
        },
    { id: 14, 
        title: "Avengers: Infinity War",
         image: InfinityWar,
          description: "Thanos seeks to collect all six Infinity Stones...", 
          rating: 4.8, 
          trailer: "https://www.youtube.com/embed/6ZfuNTqbHE8?"
         },
    { id: 15, 
        title: "Orange", 
        image: Orange, 
        description: "A Telugu romantic drama starring Ram Charan...",
         rating: 4.3, 
         trailer: "https://www.youtube.com/embed/q8GcMjkbCjo?"
         },
    { id: 16, 
        title: "Jumanji: Welcome to the Jungle", 
        image: JUMANJI, 
        description: "A group of teenagers get sucked into a magical video game...",
         rating: 4.5, 
         trailer: "https://www.youtube.com/embed/2QKg5SZ_35I?"
        }
];

const MovieDetails = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [movie, setMovie] = useState(null);

    useEffect(() => {
        const selectedMovie = movies.find((m) => m.id === parseInt(id));
        setMovie(selectedMovie);
    }, [id]);

    if (!movie) {
        return <h2>Movie not found!</h2>;
    }

    const handleBookNow = () => {
        navigate("/BookPage", { state: { movie } });
    };

    return (
        <div className="movie-details">
            <div className="left">
                <img src={movie.image} alt={movie.title} width="200" />
            </div>
            <div className="right">
                <h1>{movie.title}</h1>
                <p>{movie.description}</p>
                <p><strong>Rating:</strong> ⭐ {movie.rating} / 5</p>
                <div className="trailer-container">
                <iframe 
                    width="560" 
                    height="315" 
                    src={movie.trailer}
                    title={`${movie.title} Trailer`}
                    frameBorder="0" 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowFullScreen
                ></iframe>
            </div>
                <button onClick={handleBookNow} className="btn-movie" >Book Me</button>
            </div>
        </div>
    );
};
export default MovieDetails;